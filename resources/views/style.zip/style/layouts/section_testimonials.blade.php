{{-----------------------------------}}
@php
    $lang = session('lang');

    if (empty (session('lang')))
    {
    $lang ='ar';
    }
@endphp

{{-----------------------------------}}

<!----------------start  section title---------------------->

<!----------------End section title------------------------->
<!--============= start section teestmonls in quran (9)============ -->
<!-- testimonials -->
{{--<section class=" ">--}}
<div class="  row">
    <div class="  col-md-6">
        <!----------------start  section title---------------------->
        <section class=" title" id="testimonial">
            <div class="container ">
                <div class="section-header text-center">

                    <h2 class="h2-section-title">
                        {{trans('admin.testimonial')}}
                    </h2>
                    <div class="line">
                    </div><!--/.heazder-->
                    <span class="span-border"></span>
                </div><!--/.cont div-title-->
            </div><!--/.line-->
        </section><!--/.sec-title-->
        <!----------------End section title------------------------->
    <section class="testimonials p-relative text-center overlay_testimonial testimonial_in_quran">
             <div class=" sec-padding ">
                <div class="owl-carousel owl-theme one-catousel-custom">
                    <!-- ---------------------- -->
                    @foreach( $testimonial as $test)
                        <div class="single-review">
                            <div class="carousel-item active">
                                <div class=" our-tteam-inf  " >
                                    <div class="bak-g-c-inf"></div>
                                    <div class=" pic-inf  ">
                                        <img src="storage/{{$test->img}}">
                                    </div><!-- pic-->
                                    <div class=" team-content-inf  ">
                                        <h5 class="title-inf">{{$test['name_'.$lang]}}</h5>
                                        <p class="post-inf">   {{$test['text_'.$lang]}}</p>
                                        <p class=" ">
                                            <i class="fa fa-star fa-spin"></i>
                                            <i class="fa fa-star fa-spin"></i>
                                            <i class="fa fa-star fa-spin"></i>
                                            <i class="fa fa-star fa-spin"></i>
                                            <i class="fa fa-star fa-spin"></i>
                                        </p>
                                        <p class="post-inf text-post-inf">
                                           {{$test['job_'.$lang]}}
                                        </p>

                                        <p class="p-ul-inf ">
                      <span class="">
                    <i class="fa fa-star fa-spin"></i>
                           {{$test['country_'.$lang]}}
                   </span>
                                        </p>
                                    </div><!--team-content -->
                                </div><!-- test-info-->
                            </div><!--/.carousel-item-->
                        </div>
                @endforeach
                <!-- ---------------------- -->
                </div>
             </div><!--- sec-padding-->

     </section><!--testimonial_in_quran-->
                {{-- --------------------}}
 </div><!--col-md-6 -->
{{---------------------------------------------}}
     <div class="  col-md-6">
        <!----------------start  section title---------------------->
        <section class=" title" id="testimonial">
            <div class="container ">
                <div class="section-header text-center">

                    <h2 class="h2-section-title">
                        {{trans('admin.testimonial')}}
                    </h2>
                    <div class="line">
                    </div><!--/.heazder-->
                    <span class="span-border"></span>
                </div><!--/.cont div-title-->
            </div><!--/.line-->
        </section><!--/.sec-title-->
        <!----------------End section title------------------------->
    <section class="teestmonls_in_arabic_two p-relative text-center overlay_testimonial testimonial_in_quran">
             <div class=" sec-padding ">
                <div class="owl-carousel owl-theme one-catousel-custom">
                    <!-- ---------------------- -->
                    @foreach( $testimonial as $test)
                        <div class="single-review">
                            <div class="carousel-item active">
                                {{--                   ---------------------------------------------}}
                                <div class=" our-tteam-inf  " >
                                    <div class="bak-g-c-inf"></div>
                                    <aside class="content_teestmonls_in_arabic">

                                        <div class="container" style="height:500px;">
                                            <div class="my-slider">
                                                <ul>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>

                                                                {{--------------------------------------------------------------------}}
                                                                <style>
                                                                    #kudo-wrap{
                                                                        width: 100%;
                                                                        height: 94%;
                                                                        margin: 0 auto;
                                                                        background-image: url(https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/WaterStandingWave.jpg);
                                                                        background-size: cover;
                                                                    }

                                                                    .adj-layer {
                                                                        background-color: rgba(255, 255, 255, 0.8);
                                                                        padding: 40px;
                                                                        top: 0;
                                                                        /* left: 0; */
                                                                        width: 100%;

                                                                    }

                                                                    #kudo-wrap h1 {
                                                                        font-family: 'Pinyon Script', cursive;
                                                                        font-size: 22px;
                                                                        font-weight: bold;
                                                                        margin-bottom: 0;
                                                                        color: rgba(206,76,57,0.8);
                                                                        margin-left: 96px;
                                                                    }

                                                                    .testimonial-quote blockquote {
                                                                        /* Negate theme styles */
                                                                        border: 0;
                                                                        margin: 0;
                                                                        padding: 0;
                                                                        background: none;
                                                                        color: gray;
                                                                        font-family: Georgia, serif;
                                                                        font-size: 1.5em;
                                                                        font-style: italic;
                                                                        line-height: 1.4 !important;
                                                                        margin: 0 25px 0;
                                                                        position: relative;
                                                                        text-shadow: 0 1px #fff;
                                                                        z-index: 1;
                                                                    }

                                                                    .testimonial-quote blockquote * {
                                                                        box-sizing: border-box;
                                                                    }

                                                                    .testimonial-quote blockquote p {
                                                                        color: #75808a;
                                                                        line-height: 1!important;
                                                                        font-size: 20px;
                                                                        text-align: left;
                                                                    }

                                                                    .testimonial-quote blockquote p:first-child:before { /* quotemarks */
                                                                        content: '\201C';
                                                                        color: #39BBCE;
                                                                        font-size: 65px;
                                                                        font-weight: 700;
                                                                        opacity: .3;
                                                                        position: absolute;
                                                                        top: -34px;
                                                                        left: 83px;
                                                                        text-shadow: none;
                                                                        z-index: -300;
                                                                    }

                                                                    .testimonial-quote img {
                                                                        border: 3px solid #39BBCE;
                                                                        border-radius: 50%;
                                                                        display: block;
                                                                        width: 90px!important;
                                                                        height: 90px;
                                                                        position: absolute;
                                                                        top: -.2em;
                                                                        left: 0;
                                                                    }

                                                                    .testimonial-quote cite {
                                                                        color: gray;
                                                                        display: block;
                                                                        font-size: .8em;
                                                                    }

                                                                    .testimonial-quote cite span {
                                                                        color: #39BBCE;
                                                                        font-size: 1em;
                                                                        font-style: normal;
                                                                        font-weight: 700;
                                                                        letter-spacing: 1px;
                                                                        text-transform: uppercase;
                                                                        text-shadow: 0 1px white;
                                                                    }

                                                                    .testimonial-quote {
                                                                        position: relative;
                                                                    }

                                                                    .testimonial-quote .quote-container {
                                                                        padding-left: 80px;
                                                                    }
                                                                </style>
                                                        {{--------------------------------------------------------------------}}

                                                    </li>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>


                                                    </li>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>

                                                                {{--------------------------------------------------------------------}}
                                                                <style>
                                                                    #kudo-wrap{
                                                                        width: 100%;
                                                                        height: 94%;
                                                                        margin: 0 auto;
                                                                        background-image: url(https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/WaterStandingWave.jpg);
                                                                        background-size: cover;
                                                                    }

                                                                    .adj-layer {
                                                                        background-color: rgba(255, 255, 255, 0.8);
                                                                        padding: 40px;
                                                                        top: 0;
                                                                        /* left: 0; */
                                                                        width: 100%;

                                                                    }

                                                                    #kudo-wrap h1 {
                                                                        font-family: 'Pinyon Script', cursive;
                                                                        font-size: 22px;
                                                                        font-weight: bold;
                                                                        margin-bottom: 0;
                                                                        color: rgba(206,76,57,0.8);
                                                                        margin-left: 96px;
                                                                    }

                                                                    .testimonial-quote blockquote {
                                                                        /* Negate theme styles */
                                                                        border: 0;
                                                                        margin: 0;
                                                                        padding: 0;
                                                                        background: none;
                                                                        color: gray;
                                                                        font-family: Georgia, serif;
                                                                        font-size: 1.5em;
                                                                        font-style: italic;
                                                                        line-height: 1.4 !important;
                                                                        margin: 0 25px 0;
                                                                        position: relative;
                                                                        text-shadow: 0 1px #fff;
                                                                        z-index: 1;
                                                                    }

                                                                    .testimonial-quote blockquote * {
                                                                        box-sizing: border-box;
                                                                    }

                                                                    .testimonial-quote blockquote p {
                                                                        color: #75808a;
                                                                        line-height: 1!important;
                                                                        font-size: 20px;
                                                                        text-align: left;
                                                                    }

                                                                    .testimonial-quote blockquote p:first-child:before { /* quotemarks */
                                                                        content: '\201C';
                                                                        color: #39BBCE;
                                                                        font-size: 65px;
                                                                        font-weight: 700;
                                                                        opacity: .3;
                                                                        position: absolute;
                                                                        top: -34px;
                                                                        left: 83px;
                                                                        text-shadow: none;
                                                                        z-index: -300;
                                                                    }

                                                                    .testimonial-quote img {
                                                                        border: 3px solid #39BBCE;
                                                                        border-radius: 50%;
                                                                        display: block;
                                                                        width: 90px!important;
                                                                        height: 90px;
                                                                        position: absolute;
                                                                        top: -.2em;
                                                                        left: 0;
                                                                    }

                                                                    .testimonial-quote cite {
                                                                        color: gray;
                                                                        display: block;
                                                                        font-size: .8em;
                                                                    }

                                                                    .testimonial-quote cite span {
                                                                        color: #39BBCE;
                                                                        font-size: 1em;
                                                                        font-style: normal;
                                                                        font-weight: 700;
                                                                        letter-spacing: 1px;
                                                                        text-transform: uppercase;
                                                                        text-shadow: 0 1px white;
                                                                    }

                                                                    .testimonial-quote {
                                                                        position: relative;
                                                                    }

                                                                    .testimonial-quote .quote-container {
                                                                        padding-left: 80px;
                                                                    }
                                                                </style>
                                                        {{--------------------------------------------------------------------}}

                                                    </li>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>

                                                                {{--------------------------------------------------------------------}}
                                                                <style>
                                                                    #kudo-wrap{
                                                                        width: 100%;
                                                                        height: 94%;
                                                                        margin: 0 auto;
                                                                        background-image: url(https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/WaterStandingWave.jpg);
                                                                        background-size: cover;
                                                                    }

                                                                    .adj-layer {
                                                                        background-color: rgba(255, 255, 255, 0.8);
                                                                        padding: 40px;
                                                                        top: 0;
                                                                        /* left: 0; */
                                                                        width: 100%;

                                                                    }

                                                                    #kudo-wrap h1 {
                                                                        font-family: 'Pinyon Script', cursive;
                                                                        font-size: 22px;
                                                                        font-weight: bold;
                                                                        margin-bottom: 0;
                                                                        color: rgba(206,76,57,0.8);
                                                                        margin-left: 96px;
                                                                    }

                                                                    .testimonial-quote blockquote {
                                                                        /* Negate theme styles */
                                                                        border: 0;
                                                                        margin: 0;
                                                                        padding: 0;
                                                                        background: none;
                                                                        color: gray;
                                                                        font-family: Georgia, serif;
                                                                        font-size: 1.5em;
                                                                        font-style: italic;
                                                                        line-height: 1.4 !important;
                                                                        margin: 0 25px 0;
                                                                        position: relative;
                                                                        text-shadow: 0 1px #fff;
                                                                        z-index: 1;
                                                                    }

                                                                    .testimonial-quote blockquote * {
                                                                        box-sizing: border-box;
                                                                    }

                                                                    .testimonial-quote blockquote p {
                                                                        color: #75808a;
                                                                        line-height: 1!important;
                                                                        font-size: 20px;
                                                                        text-align: left;
                                                                    }

                                                                    .testimonial-quote blockquote p:first-child:before { /* quotemarks */
                                                                        content: '\201C';
                                                                        color: #39BBCE;
                                                                        font-size: 65px;
                                                                        font-weight: 700;
                                                                        opacity: .3;
                                                                        position: absolute;
                                                                        top: -34px;
                                                                        left: 83px;
                                                                        text-shadow: none;
                                                                        z-index: -300;
                                                                    }

                                                                    .testimonial-quote img {
                                                                        border: 3px solid #39BBCE;
                                                                        border-radius: 50%;
                                                                        display: block;
                                                                        width: 90px!important;
                                                                        height: 90px;
                                                                        position: absolute;
                                                                        top: -.2em;
                                                                        left: 0;
                                                                    }

                                                                    .testimonial-quote cite {
                                                                        color: gray;
                                                                        display: block;
                                                                        font-size: .8em;
                                                                    }

                                                                    .testimonial-quote cite span {
                                                                        color: #39BBCE;
                                                                        font-size: 1em;
                                                                        font-style: normal;
                                                                        font-weight: 700;
                                                                        letter-spacing: 1px;
                                                                        text-transform: uppercase;
                                                                        text-shadow: 0 1px white;
                                                                    }

                                                                    .testimonial-quote {
                                                                        position: relative;
                                                                    }

                                                                    .testimonial-quote .quote-container {
                                                                        padding-left: 80px;
                                                                    }
                                                                </style>
                                                        {{--------------------------------------------------------------------}}

                                                    </li>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>

                                                                {{--------------------------------------------------------------------}}
                                                                <style>
                                                                    #kudo-wrap{
                                                                        width: 100%;
                                                                        height: 94%;
                                                                        margin: 0 auto;
                                                                        background-image: url(https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/WaterStandingWave.jpg);
                                                                        background-size: cover;
                                                                    }

                                                                    .adj-layer {
                                                                        background-color: rgba(255, 255, 255, 0.8);
                                                                        padding: 40px;
                                                                        top: 0;
                                                                        /* left: 0; */
                                                                        width: 100%;

                                                                    }

                                                                    #kudo-wrap h1 {
                                                                        font-family: 'Pinyon Script', cursive;
                                                                        font-size: 22px;
                                                                        font-weight: bold;
                                                                        margin-bottom: 0;
                                                                        color: rgba(206,76,57,0.8);
                                                                        margin-left: 96px;
                                                                    }

                                                                    .testimonial-quote blockquote {
                                                                        /* Negate theme styles */
                                                                        border: 0;
                                                                        margin: 0;
                                                                        padding: 0;
                                                                        background: none;
                                                                        color: gray;
                                                                        font-family: Georgia, serif;
                                                                        font-size: 1.5em;
                                                                        font-style: italic;
                                                                        line-height: 1.4 !important;
                                                                        margin: 0 25px 0;
                                                                        position: relative;
                                                                        text-shadow: 0 1px #fff;
                                                                        z-index: 1;
                                                                    }

                                                                    .testimonial-quote blockquote * {
                                                                        box-sizing: border-box;
                                                                    }

                                                                    .testimonial-quote blockquote p {
                                                                        color: #75808a;
                                                                        line-height: 1!important;
                                                                        font-size: 20px;
                                                                        text-align: left;
                                                                    }

                                                                    .testimonial-quote blockquote p:first-child:before { /* quotemarks */
                                                                        content: '\201C';
                                                                        color: #39BBCE;
                                                                        font-size: 65px;
                                                                        font-weight: 700;
                                                                        opacity: .3;
                                                                        position: absolute;
                                                                        top: -34px;
                                                                        left: 83px;
                                                                        text-shadow: none;
                                                                        z-index: -300;
                                                                    }

                                                                    .testimonial-quote img {
                                                                        border: 3px solid #39BBCE;
                                                                        border-radius: 50%;
                                                                        display: block;
                                                                        width: 90px!important;
                                                                        height: 90px;
                                                                        position: absolute;
                                                                        top: -.2em;
                                                                        left: 0;
                                                                    }

                                                                    .testimonial-quote cite {
                                                                        color: gray;
                                                                        display: block;
                                                                        font-size: .8em;
                                                                    }

                                                                    .testimonial-quote cite span {
                                                                        color: #39BBCE;
                                                                        font-size: 1em;
                                                                        font-style: normal;
                                                                        font-weight: 700;
                                                                        letter-spacing: 1px;
                                                                        text-transform: uppercase;
                                                                        text-shadow: 0 1px white;
                                                                    }

                                                                    .testimonial-quote {
                                                                        position: relative;
                                                                    }

                                                                    .testimonial-quote .quote-container {
                                                                        padding-left: 80px;
                                                                    }
                                                                </style>
                                                        {{--------------------------------------------------------------------}}

                                                    </li>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>

                                                                {{--------------------------------------------------------------------}}
                                                                <style>
                                                                    #kudo-wrap{
                                                                        width: 100%;
                                                                        height: 94%;
                                                                        margin: 0 auto;
                                                                        background-image: url(https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/WaterStandingWave.jpg);
                                                                        background-size: cover;
                                                                    }

                                                                    .adj-layer {
                                                                        background-color: rgba(255, 255, 255, 0.8);
                                                                        padding: 40px;
                                                                        top: 0;
                                                                        /* left: 0; */
                                                                        width: 100%;

                                                                    }

                                                                    #kudo-wrap h1 {
                                                                        font-family: 'Pinyon Script', cursive;
                                                                        font-size: 22px;
                                                                        font-weight: bold;
                                                                        margin-bottom: 0;
                                                                        color: rgba(206,76,57,0.8);
                                                                        margin-left: 96px;
                                                                    }

                                                                    .testimonial-quote blockquote {
                                                                        /* Negate theme styles */
                                                                        border: 0;
                                                                        margin: 0;
                                                                        padding: 0;
                                                                        background: none;
                                                                        color: gray;
                                                                        font-family: Georgia, serif;
                                                                        font-size: 1.5em;
                                                                        font-style: italic;
                                                                        line-height: 1.4 !important;
                                                                        margin: 0 25px 0;
                                                                        position: relative;
                                                                        text-shadow: 0 1px #fff;
                                                                        z-index: 1;
                                                                    }

                                                                    .testimonial-quote blockquote * {
                                                                        box-sizing: border-box;
                                                                    }

                                                                    .testimonial-quote blockquote p {
                                                                        color: #75808a;
                                                                        line-height: 1!important;
                                                                        font-size: 20px;
                                                                        text-align: left;
                                                                    }

                                                                    .testimonial-quote blockquote p:first-child:before { /* quotemarks */
                                                                        content: '\201C';
                                                                        color: #39BBCE;
                                                                        font-size: 65px;
                                                                        font-weight: 700;
                                                                        opacity: .3;
                                                                        position: absolute;
                                                                        top: -34px;
                                                                        left: 83px;
                                                                        text-shadow: none;
                                                                        z-index: -300;
                                                                    }

                                                                    .testimonial-quote img {
                                                                        border: 3px solid #39BBCE;
                                                                        border-radius: 50%;
                                                                        display: block;
                                                                        width: 90px!important;
                                                                        height: 90px;
                                                                        position: absolute;
                                                                        top: -.2em;
                                                                        left: 0;
                                                                    }

                                                                    .testimonial-quote cite {
                                                                        color: gray;
                                                                        display: block;
                                                                        font-size: .8em;
                                                                    }

                                                                    .testimonial-quote cite span {
                                                                        color: #39BBCE;
                                                                        font-size: 1em;
                                                                        font-style: normal;
                                                                        font-weight: 700;
                                                                        letter-spacing: 1px;
                                                                        text-transform: uppercase;
                                                                        text-shadow: 0 1px white;
                                                                    }

                                                                    .testimonial-quote {
                                                                        position: relative;
                                                                    }

                                                                    .testimonial-quote .quote-container {
                                                                        padding-left: 80px;
                                                                    }
                                                                </style>
                                                        {{--------------------------------------------------------------------}}

                                                    </li>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>

                                                                {{--------------------------------------------------------------------}}
                                                                <style>
                                                                    #kudo-wrap{
                                                                        width: 100%;
                                                                        height: 94%;
                                                                        margin: 0 auto;
                                                                        background-image: url(https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/WaterStandingWave.jpg);
                                                                        background-size: cover;
                                                                    }

                                                                    .adj-layer {
                                                                        background-color: rgba(255, 255, 255, 0.8);
                                                                        padding: 40px;
                                                                        top: 0;
                                                                        /* left: 0; */
                                                                        width: 100%;

                                                                    }

                                                                    #kudo-wrap h1 {
                                                                        font-family: 'Pinyon Script', cursive;
                                                                        font-size: 22px;
                                                                        font-weight: bold;
                                                                        margin-bottom: 0;
                                                                        color: rgba(206,76,57,0.8);
                                                                        margin-left: 96px;
                                                                    }

                                                                    .testimonial-quote blockquote {
                                                                        /* Negate theme styles */
                                                                        border: 0;
                                                                        margin: 0;
                                                                        padding: 0;
                                                                        background: none;
                                                                        color: gray;
                                                                        font-family: Georgia, serif;
                                                                        font-size: 1.5em;
                                                                        font-style: italic;
                                                                        line-height: 1.4 !important;
                                                                        margin: 0 25px 0;
                                                                        position: relative;
                                                                        text-shadow: 0 1px #fff;
                                                                        z-index: 1;
                                                                    }

                                                                    .testimonial-quote blockquote * {
                                                                        box-sizing: border-box;
                                                                    }

                                                                    .testimonial-quote blockquote p {
                                                                        color: #75808a;
                                                                        line-height: 1!important;
                                                                        font-size: 20px;
                                                                        text-align: left;
                                                                    }

                                                                    .testimonial-quote blockquote p:first-child:before { /* quotemarks */
                                                                        content: '\201C';
                                                                        color: #39BBCE;
                                                                        font-size: 65px;
                                                                        font-weight: 700;
                                                                        opacity: .3;
                                                                        position: absolute;
                                                                        top: -34px;
                                                                        left: 83px;
                                                                        text-shadow: none;
                                                                        z-index: -300;
                                                                    }

                                                                    .testimonial-quote img {
                                                                        border: 3px solid #39BBCE;
                                                                        border-radius: 50%;
                                                                        display: block;
                                                                        width: 90px!important;
                                                                        height: 90px;
                                                                        position: absolute;
                                                                        top: -.2em;
                                                                        left: 0;
                                                                    }

                                                                    .testimonial-quote cite {
                                                                        color: gray;
                                                                        display: block;
                                                                        font-size: .8em;
                                                                    }

                                                                    .testimonial-quote cite span {
                                                                        color: #39BBCE;
                                                                        font-size: 1em;
                                                                        font-style: normal;
                                                                        font-weight: 700;
                                                                        letter-spacing: 1px;
                                                                        text-transform: uppercase;
                                                                        text-shadow: 0 1px white;
                                                                    }

                                                                    .testimonial-quote {
                                                                        position: relative;
                                                                    }

                                                                    .testimonial-quote .quote-container {
                                                                        padding-left: 80px;
                                                                    }
                                                                </style>
                                                        {{--------------------------------------------------------------------}}

                                                    </li>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>

                                                                {{--------------------------------------------------------------------}}
                                                                <style>
                                                                    #kudo-wrap{
                                                                        width: 100%;
                                                                        height: 94%;
                                                                        margin: 0 auto;
                                                                        background-image: url(https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/WaterStandingWave.jpg);
                                                                        background-size: cover;
                                                                    }

                                                                    .adj-layer {
                                                                        background-color: rgba(255, 255, 255, 0.8);
                                                                        padding: 40px;
                                                                        top: 0;
                                                                        /* left: 0; */
                                                                        width: 100%;

                                                                    }

                                                                    #kudo-wrap h1 {
                                                                        font-family: 'Pinyon Script', cursive;
                                                                        font-size: 22px;
                                                                        font-weight: bold;
                                                                        margin-bottom: 0;
                                                                        color: rgba(206,76,57,0.8);
                                                                        margin-left: 96px;
                                                                    }

                                                                    .testimonial-quote blockquote {
                                                                        /* Negate theme styles */
                                                                        border: 0;
                                                                        margin: 0;
                                                                        padding: 0;
                                                                        background: none;
                                                                        color: gray;
                                                                        font-family: Georgia, serif;
                                                                        font-size: 1.5em;
                                                                        font-style: italic;
                                                                        line-height: 1.4 !important;
                                                                        margin: 0 25px 0;
                                                                        position: relative;
                                                                        text-shadow: 0 1px #fff;
                                                                        z-index: 1;
                                                                    }

                                                                    .testimonial-quote blockquote * {
                                                                        box-sizing: border-box;
                                                                    }

                                                                    .testimonial-quote blockquote p {
                                                                        color: #75808a;
                                                                        line-height: 1!important;
                                                                        font-size: 20px;
                                                                        text-align: left;
                                                                    }

                                                                    .testimonial-quote blockquote p:first-child:before { /* quotemarks */
                                                                        content: '\201C';
                                                                        color: #39BBCE;
                                                                        font-size: 65px;
                                                                        font-weight: 700;
                                                                        opacity: .3;
                                                                        position: absolute;
                                                                        top: -34px;
                                                                        left: 83px;
                                                                        text-shadow: none;
                                                                        z-index: -300;
                                                                    }

                                                                    .testimonial-quote img {
                                                                        border: 3px solid #39BBCE;
                                                                        border-radius: 50%;
                                                                        display: block;
                                                                        width: 90px!important;
                                                                        height: 90px;
                                                                        position: absolute;
                                                                        top: -.2em;
                                                                        left: 0;
                                                                    }

                                                                    .testimonial-quote cite {
                                                                        color: gray;
                                                                        display: block;
                                                                        font-size: .8em;
                                                                    }

                                                                    .testimonial-quote cite span {
                                                                        color: #39BBCE;
                                                                        font-size: 1em;
                                                                        font-style: normal;
                                                                        font-weight: 700;
                                                                        letter-spacing: 1px;
                                                                        text-transform: uppercase;
                                                                        text-shadow: 0 1px white;
                                                                    }

                                                                    .testimonial-quote {
                                                                        position: relative;
                                                                    }

                                                                    .testimonial-quote .quote-container {
                                                                        padding-left: 80px;
                                                                    }
                                                                </style>
                                                        {{--------------------------------------------------------------------}}

                                                    </li>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>

                                                                {{--------------------------------------------------------------------}}
                                                                <style>
                                                                    #kudo-wrap{
                                                                        width: 100%;
                                                                        height: 94%;
                                                                        margin: 0 auto;
                                                                        background-image: url(https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/WaterStandingWave.jpg);
                                                                        background-size: cover;
                                                                    }

                                                                    .adj-layer {
                                                                        background-color: rgba(255, 255, 255, 0.8);
                                                                        padding: 40px;
                                                                        top: 0;
                                                                        /* left: 0; */
                                                                        width: 100%;

                                                                    }

                                                                    #kudo-wrap h1 {
                                                                        font-family: 'Pinyon Script', cursive;
                                                                        font-size: 22px;
                                                                        font-weight: bold;
                                                                        margin-bottom: 0;
                                                                        color: rgba(206,76,57,0.8);
                                                                        margin-left: 96px;
                                                                    }

                                                                    .testimonial-quote blockquote {
                                                                        /* Negate theme styles */
                                                                        border: 0;
                                                                        margin: 0;
                                                                        padding: 0;
                                                                        background: none;
                                                                        color: gray;
                                                                        font-family: Georgia, serif;
                                                                        font-size: 1.5em;
                                                                        font-style: italic;
                                                                        line-height: 1.4 !important;
                                                                        margin: 0 25px 0;
                                                                        position: relative;
                                                                        text-shadow: 0 1px #fff;
                                                                        z-index: 1;
                                                                    }

                                                                    .testimonial-quote blockquote * {
                                                                        box-sizing: border-box;
                                                                    }

                                                                    .testimonial-quote blockquote p {
                                                                        color: #75808a;
                                                                        line-height: 1!important;
                                                                        font-size: 20px;
                                                                        text-align: left;
                                                                    }

                                                                    .testimonial-quote blockquote p:first-child:before { /* quotemarks */
                                                                        content: '\201C';
                                                                        color: #39BBCE;
                                                                        font-size: 65px;
                                                                        font-weight: 700;
                                                                        opacity: .3;
                                                                        position: absolute;
                                                                        top: -34px;
                                                                        left: 83px;
                                                                        text-shadow: none;
                                                                        z-index: -300;
                                                                    }

                                                                    .testimonial-quote img {
                                                                        border: 3px solid #39BBCE;
                                                                        border-radius: 50%;
                                                                        display: block;
                                                                        width: 90px!important;
                                                                        height: 90px;
                                                                        position: absolute;
                                                                        top: -.2em;
                                                                        left: 0;
                                                                    }

                                                                    .testimonial-quote cite {
                                                                        color: gray;
                                                                        display: block;
                                                                        font-size: .8em;
                                                                    }

                                                                    .testimonial-quote cite span {
                                                                        color: #39BBCE;
                                                                        font-size: 1em;
                                                                        font-style: normal;
                                                                        font-weight: 700;
                                                                        letter-spacing: 1px;
                                                                        text-transform: uppercase;
                                                                        text-shadow: 0 1px white;
                                                                    }

                                                                    .testimonial-quote {
                                                                        position: relative;
                                                                    }

                                                                    .testimonial-quote .quote-container {
                                                                        padding-left: 80px;
                                                                    }
                                                                </style>
                                                        {{--------------------------------------------------------------------}}

                                                    </li>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>

                                                                {{--------------------------------------------------------------------}}
                                                                <style>
                                                                    #kudo-wrap{
                                                                        width: 100%;
                                                                        height: 94%;
                                                                        margin: 0 auto;
                                                                        background-image: url(https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/WaterStandingWave.jpg);
                                                                        background-size: cover;
                                                                    }

                                                                    .adj-layer {
                                                                        background-color: rgba(255, 255, 255, 0.8);
                                                                        padding: 40px;
                                                                        top: 0;
                                                                        /* left: 0; */
                                                                        width: 100%;

                                                                    }

                                                                    #kudo-wrap h1 {
                                                                        font-family: 'Pinyon Script', cursive;
                                                                        font-size: 22px;
                                                                        font-weight: bold;
                                                                        margin-bottom: 0;
                                                                        color: rgba(206,76,57,0.8);
                                                                        margin-left: 96px;
                                                                    }

                                                                    .testimonial-quote blockquote {
                                                                        /* Negate theme styles */
                                                                        border: 0;
                                                                        margin: 0;
                                                                        padding: 0;
                                                                        background: none;
                                                                        color: gray;
                                                                        font-family: Georgia, serif;
                                                                        font-size: 1.5em;
                                                                        font-style: italic;
                                                                        line-height: 1.4 !important;
                                                                        margin: 0 25px 0;
                                                                        position: relative;
                                                                        text-shadow: 0 1px #fff;
                                                                        z-index: 1;
                                                                    }

                                                                    .testimonial-quote blockquote * {
                                                                        box-sizing: border-box;
                                                                    }

                                                                    .testimonial-quote blockquote p {
                                                                        color: #75808a;
                                                                        line-height: 1!important;
                                                                        font-size: 20px;
                                                                        text-align: left;
                                                                    }

                                                                    .testimonial-quote blockquote p:first-child:before { /* quotemarks */
                                                                        content: '\201C';
                                                                        color: #39BBCE;
                                                                        font-size: 65px;
                                                                        font-weight: 700;
                                                                        opacity: .3;
                                                                        position: absolute;
                                                                        top: -34px;
                                                                        left: 83px;
                                                                        text-shadow: none;
                                                                        z-index: -300;
                                                                    }

                                                                    .testimonial-quote img {
                                                                        border: 3px solid #39BBCE;
                                                                        border-radius: 50%;
                                                                        display: block;
                                                                        width: 90px!important;
                                                                        height: 90px;
                                                                        position: absolute;
                                                                        top: -.2em;
                                                                        left: 0;
                                                                    }

                                                                    .testimonial-quote cite {
                                                                        color: gray;
                                                                        display: block;
                                                                        font-size: .8em;
                                                                    }

                                                                    .testimonial-quote cite span {
                                                                        color: #39BBCE;
                                                                        font-size: 1em;
                                                                        font-style: normal;
                                                                        font-weight: 700;
                                                                        letter-spacing: 1px;
                                                                        text-transform: uppercase;
                                                                        text-shadow: 0 1px white;
                                                                    }

                                                                    .testimonial-quote {
                                                                        position: relative;
                                                                    }

                                                                    .testimonial-quote .quote-container {
                                                                        padding-left: 80px;
                                                                    }
                                                                </style>
                                                        {{--------------------------------------------------------------------}}

                                                    </li>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>

                                                                {{--------------------------------------------------------------------}}
                                                                <style>
                                                                    #kudo-wrap{
                                                                        width: 100%;
                                                                        height: 94%;
                                                                        margin: 0 auto;
                                                                        background-image: url(https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/WaterStandingWave.jpg);
                                                                        background-size: cover;
                                                                    }

                                                                    .adj-layer {
                                                                        background-color: rgba(255, 255, 255, 0.8);
                                                                        padding: 40px;
                                                                        top: 0;
                                                                        /* left: 0; */
                                                                        width: 100%;

                                                                    }

                                                                    #kudo-wrap h1 {
                                                                        font-family: 'Pinyon Script', cursive;
                                                                        font-size: 22px;
                                                                        font-weight: bold;
                                                                        margin-bottom: 0;
                                                                        color: rgba(206,76,57,0.8);
                                                                        margin-left: 96px;
                                                                    }

                                                                    .testimonial-quote blockquote {
                                                                        /* Negate theme styles */
                                                                        border: 0;
                                                                        margin: 0;
                                                                        padding: 0;
                                                                        background: none;
                                                                        color: gray;
                                                                        font-family: Georgia, serif;
                                                                        font-size: 1.5em;
                                                                        font-style: italic;
                                                                        line-height: 1.4 !important;
                                                                        margin: 0 25px 0;
                                                                        position: relative;
                                                                        text-shadow: 0 1px #fff;
                                                                        z-index: 1;
                                                                    }

                                                                    .testimonial-quote blockquote * {
                                                                        box-sizing: border-box;
                                                                    }

                                                                    .testimonial-quote blockquote p {
                                                                        color: #75808a;
                                                                        line-height: 1!important;
                                                                        font-size: 20px;
                                                                        text-align: left;
                                                                    }

                                                                    .testimonial-quote blockquote p:first-child:before { /* quotemarks */
                                                                        content: '\201C';
                                                                        color: #39BBCE;
                                                                        font-size: 65px;
                                                                        font-weight: 700;
                                                                        opacity: .3;
                                                                        position: absolute;
                                                                        top: -34px;
                                                                        left: 83px;
                                                                        text-shadow: none;
                                                                        z-index: -300;
                                                                    }

                                                                    .testimonial-quote img {
                                                                        border: 3px solid #39BBCE;
                                                                        border-radius: 50%;
                                                                        display: block;
                                                                        width: 90px!important;
                                                                        height: 90px;
                                                                        position: absolute;
                                                                        top: -.2em;
                                                                        left: 0;
                                                                    }

                                                                    .testimonial-quote cite {
                                                                        color: gray;
                                                                        display: block;
                                                                        font-size: .8em;
                                                                    }

                                                                    .testimonial-quote cite span {
                                                                        color: #39BBCE;
                                                                        font-size: 1em;
                                                                        font-style: normal;
                                                                        font-weight: 700;
                                                                        letter-spacing: 1px;
                                                                        text-transform: uppercase;
                                                                        text-shadow: 0 1px white;
                                                                    }

                                                                    .testimonial-quote {
                                                                        position: relative;
                                                                    }

                                                                    .testimonial-quote .quote-container {
                                                                        padding-left: 80px;
                                                                    }
                                                                </style>
                                                        {{--------------------------------------------------------------------}}

                                                    </li>
                                                    <li>

                                                        <div id="kudo-wrap">
                                                            <div class="adj-layer">
                                                                <h1>Kudos</h1>
                                                                <div class="testimonial-quote group">
                                                                    <img src="https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/Jan-Alexander-La-Jolla-Shores-Beach-Square-400x400.jpg">
                                                                    <div class="quote-container">
                                                                        <blockquote>
                                                                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit justo augue, vitae lobortis sapien interdum ut. Phasellus condimentum leo ut sem pulvinar, in sodales erat feugiat. Pellentesque ac cursus odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. ”</p>
                                                                        </blockquote>
                                                                        <cite><span>Jan Baby</span><br>
                                                                            RMT<br>
                                                                            TLC Medical Massage
                                                                        </cite>
                                                                    </div>

                                                                </div>

                                                                {{--------------------------------------------------------------------}}
                                                                <style>
                                                                    #kudo-wrap{
                                                                        width: 100%;
                                                                        height: 94%;
                                                                        margin: 0 auto;
                                                                        background-image: url(https://s3.amazonaws.com/tlcmedicalmassage/wp-content/uploads/WaterStandingWave.jpg);
                                                                        background-size: cover;
                                                                    }

                                                                    .adj-layer {
                                                                        background-color: rgba(255, 255, 255, 0.8);
                                                                        padding: 40px;
                                                                        top: 0;
                                                                        /* left: 0; */
                                                                        width: 100%;

                                                                    }

                                                                    #kudo-wrap h1 {
                                                                        font-family: 'Pinyon Script', cursive;
                                                                        font-size: 22px;
                                                                        font-weight: bold;
                                                                        margin-bottom: 0;
                                                                        color: rgba(206,76,57,0.8);
                                                                        margin-left: 96px;
                                                                    }

                                                                    .testimonial-quote blockquote {
                                                                        /* Negate theme styles */
                                                                        border: 0;
                                                                        margin: 0;
                                                                        padding: 0;
                                                                        background: none;
                                                                        color: gray;
                                                                        font-family: Georgia, serif;
                                                                        font-size: 1.5em;
                                                                        font-style: italic;
                                                                        line-height: 1.4 !important;
                                                                        margin: 0 25px 0;
                                                                        position: relative;
                                                                        text-shadow: 0 1px #fff;
                                                                        z-index: 1;
                                                                    }

                                                                    .testimonial-quote blockquote * {
                                                                        box-sizing: border-box;
                                                                    }

                                                                    .testimonial-quote blockquote p {
                                                                        color: #75808a;
                                                                        line-height: 1!important;
                                                                        font-size: 20px;
                                                                        text-align: left;
                                                                    }

                                                                    .testimonial-quote blockquote p:first-child:before { /* quotemarks */
                                                                        content: '\201C';
                                                                        color: #39BBCE;
                                                                        font-size: 65px;
                                                                        font-weight: 700;
                                                                        opacity: .3;
                                                                        position: absolute;
                                                                        top: -34px;
                                                                        left: 83px;
                                                                        text-shadow: none;
                                                                        z-index: -300;
                                                                    }

                                                                    .testimonial-quote img {
                                                                        border: 3px solid #39BBCE;
                                                                        border-radius: 50%;
                                                                        display: block;
                                                                        width: 90px!important;
                                                                        height: 90px;
                                                                        position: absolute;
                                                                        top: -.2em;
                                                                        left: 0;
                                                                    }

                                                                    .testimonial-quote cite {
                                                                        color: gray;
                                                                        display: block;
                                                                        font-size: .8em;
                                                                    }

                                                                    .testimonial-quote cite span {
                                                                        color: #39BBCE;
                                                                        font-size: 1em;
                                                                        font-style: normal;
                                                                        font-weight: 700;
                                                                        letter-spacing: 1px;
                                                                        text-transform: uppercase;
                                                                        text-shadow: 0 1px white;
                                                                    }

                                                                    .testimonial-quote {
                                                                        position: relative;
                                                                    }

                                                                    .testimonial-quote .quote-container {
                                                                        padding-left: 80px;
                                                                    }
                                                                    .cardslider__card--index-0{
                                                                       background:  transparent!important;
                                                                    }
                                                                </style>

                                                        {{--------------------------------------------------------------------}}

                                                    </li>

                                                </ul>
                                            </div>
                                        </div>

                                    </aside><!--End content_teestmonls_in_arabic-->
                                    <div class=" team-content-inf  ">
                                        <p class="p-ul-inf ">    <span class=""><i class="fa fa-star fa-spin"></i> footer</span>
                                        </p>
                                    </div><!--team-content -->
                                </div><!-- test-info-->
                                {{--                   ---------------------------------------------}}
                            </div><!--/.carousel-item-->
                        </div>
                @endforeach
                <!-- ---------------------- -->
                </div>
             </div><!--- sec-padding-->

     </section><!--testimonial_in_quran-->
                {{-- --------------------}}
 </div><!--col-md-6 -->
{{---------------------------------------------}}

        </section><!--testimonial_in_quran-->
        {{-- --------------------}}
    </div><!--col-md-6 -->
{{---------------------------------------------}}


</div><!--row -->

<!--============= End section teestmonls in quran  (10?)============ -->
