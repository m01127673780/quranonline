     <style>
    /*======================================================================*/

  .none{
    display: none;
  }
  body{
    background-color: #fff;
  }
    #zero{
    margin-top: 20px;
  } 
  .color_yellow{
  color:#ffcc00;
  }
/*======================================================================*/

 

    html {
        line-height: 1;
    }

    ol, ul {
        list-style: none;
    }

    table {
        border-collapse: collapse;
        border-spacing: 0;
    }

    caption, th, td {
        text-align: left;
        font-weight: normal;
        vertical-align: middle;
    }

    q, blockquote {
        quotes: none;
    }
    q:before, q:after, blockquote:before, blockquote:after {
        content: "";
        content: none;
    }

    a img {
        border: none;
    }

    article, aside, details, figcaption, figure, footer, header, hgroup, main, menu, nav, section, summary {
        display: block;
    }

    /* Colors */
    /* ---------------------------------------- */
    * {
        -moz-box-sizing: border-box;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
    }


    a {
        text-decoration: none;
    }

    .info-text {
        text-align: left;
        width: 100%;
    }

    header, form {
        padding: 4em 10%;
        text-align: left;
    }

    .form-group {
        margin-bottom: 20px;
    }

    h2.heading {
        font-size: 18px;
        text-transform: uppercase;
        font-weight: 300;
        text-align: left;
        color: #506982;
        border-bottom: 1px solid #506982;
        padding-bottom: 3px;
        margin-bottom: 20px;
    }

    .controls {
        text-align: left;
        position: relative;
        margin-bottom: 11px;
    }
    .controls input[type="text"],
    .controls input[type="email"],
    .controls input[type="number"],
    .controls input[type="date"],
    .controls input[type="tel"],
    .controls input,
    .controls .text1,
    .controls textarea,
    .controls button,
    .controls select {
        padding: 12px;
        font-size: 14px;
        border: 1px solid #c6c6c6;
        width: 100%;
        margin-bottom: 18px;
        color: #888;
        font-family: 'Lato', 'sans-serif';
        font-size: 16px;
        font-weight: 300;
        -moz-border-radius: 2px;
        -webkit-border-radius: 2px;
        border-radius: 2px;
        -moz-transition: all 0.3s;
        -o-transition: all 0.3s;
        -webkit-transition: all 0.3s;
        transition: all 0.3s;
        height: 50px;
    }
    .controls input[type="text"]:focus,
    .controls input[type="text"]:hover,
    .controls input[type="email"]:focus,
    .controls input[type="email"]:hover,
    .controls input[type="number"]:focus,
    .controls input[type="number"]:hover,
    .controls input[type="date"]:focus,
    .controls input[type="date"]:hover,
    .controls input[type="tel"]:focus,
    .controls input[type="tel"]:hover,
    .controls input[type="text"]:focus,
    .controls input[type="text"]:hover,
    .controls input:focus,
    .controls input:hover,
    .controls .text:hover,
    .controls .text:focus,
    .controls .text1:hover,
    .controls .text1:focus,
    .controls textarea:focus,
    .controls textarea:hover,
    .controls button:focus,
    .controls button:hover,
    .controls select:focus,
    .controls select:hover {
        outline: none;
        border-color: #9FB1C1;
    }
    .controls input[type="text"]:focus + label,
    .controls input[type="text"]:hover + label,
    .controls input[type="email"]:focus + label,
    .controls input[type="email"]:hover + label,
    .controls input[type="number"]:focus + label,
    .controls input[type="number"]:hover + label,
    .controls input[type="date"]:focus + label,
    .controls input[type="date"]:hover + label,
    .controls input[type="tel"]:focus + label,
    .controls input[type="tel"]:hover + label,
    .controls input:focus + label,
    .controls input:hover + label,
    .controls .text:focus + label,
    .controls .text:hover + label,
    .controls .text1:focus + label,
    .controls .text1:hover + label,
    .controls textarea:focus + label,
    .controls textarea:hover + label,
    .controls button:focus + label,
    .controls button:hover + label,
    .controls select:focus + label,
    .controls select:hover + label {
        color: #bdcc00;
        cursor: text;
    }
    .controls .fa-sort {
        position: absolute;
        right: 10px;
        top: 17px;
        color: #999;
    }
    .controls select {
        -moz-appearance: none;
        -webkit-appearance: none;
        cursor: pointer;
        padding: 20px 0;
        /*  width: 106%!important;
         margin-left: -14px!important;*/
    }
    .controls label {
        position: absolute;
        left: 8px;
        top: 12px;
        width: 60%;
        color: #999;
        font-size: 16px;
        display: inline-block;
        padding: 4px 10px;
        font-weight: 400;
        background-color: rgba(255, 255, 255, 0);
        -moz-transition: color 0.3s, top 0.3s, background-color 0.8s;
        -o-transition: color 0.3s, top 0.3s, background-color 0.8s;
        -webkit-transition: color 0.3s, top 0.3s, background-color 0.8s;
        transition: color 0.3s, top 0.3s, background-color 0.8s;
        background-color: white;
    }
    .controls label.active {
        top: -22px;
        color: #555;
        background-color: white;
        width: auto;
    }
    .controls textarea {
        resize: none;
        height: 200px;
        padding: 50px;
        width:120%;
        border-style: dashed;
    }

    button {
        cursor: pointer;
        background-color: #1b3d4d;
        border: none;
        color: #fff;
        padding: 12px 0;
        float: right;
    }
    button:hover {
        background-color: #224c60;
    }

    .clear:after {
        content: "";
        display: table;
        clear: both;
    }

    .grid {
        background: white;
    }
    .grid:after {
        /* Or @extend clearfix */
        content: "";
        display: table;
        clear: both;
    }

    [class*='col-'] {
        float: left;
        padding-right: 10px;
    }
    .grid [class*='col-']:last-of-type {
        padding-right: 0;
    }

    .col-2-3 {
        width: 66.66%;
    }

    .col-1-3 {
        width: 33.33%;
    }

    .col-1-2 {
        width: 50%;
    }

    .col-1-4 {
        width: 25%;
    }

    @media (max-width: 760px) {
        .col-1-4-sm, .col-1-3, .col-2-3 {
            width: 100%;
        }

        [class*='col-'] {
            padding-right: 0px;
        }
    }
    .col-1-8 {
        width: 12.5%;
    }

    /*----------------------------------*/

    /*{
          font-size: 21px;
        text-transform: uppercase;
        font-weight: 300;
        color: #2a333b;
        margin-bottom: 51px;

    } */
    .head-h1{

        margin-bottom: 40px;
    }
    .head-h1.info-stud-insert {
        margin-bottom: 5px;
        margin-top: -22px;
    }
    .controls.label-copy   {
        top:-18px!important;
    }
    option   {
        padding-left: 26px;
    }

    select.form-control:not([size]):not([multiple]) {
        height: 48px!important;
        font-size: 15px;
    }
    textarea {
        border:9px dashed #222;
        padding: 
    }
    .input-date{
        height: 50px!important;
    }

    .custom-select.floatLabel{
        width: 106%!important;
        margin-left: -14px!important;
    }
    .width-full  {

        width: 100%!important;
    }

    .width-full  .head-studant  {

        margin: 30px 0;
        margin-bottom:50px;
    }
    /*.width-full  .head-studant.one-head  {
    margin: 30px 0!important;

    }*/
    .width-full  .head-studant span {

        border-bottom: 2px solid #000;

    }
    label {
        display: inline-block;
        margin-bottom: .5rem;
        font-size: 18px;
    }

    .col.col-margin-bottom  {
        margin-top: -31px!important;
        color: #999999;
    }
    .col.col-margin-bottom label {
        margin-left: 16px;
        font-size: 16px;
    }
    .controls.label-copy {
        top: -4px!important;
        margin-bottom: 40px;
    }
    .input-date {
        width:106%!important;
        margin-left: -16px;
    }
    .head-h1.PREFERRED {
        margin: 60px 0;
    }
    label.head-smol {
        display: inline-block;
        margin-bottom: 20px!important;
        margin-left: 0;
    }
    #divRegFormVideo {
        position: fixed;
        z-index: 99999;
    }
    @media(max-width:992px){
            #divRegFormVideo {
        position: relative!important;
         
         }
     }
               .col_5_video {
         margin-top: 68px!important;
    
    }
    .col-lg-7-box-shadow{
        box-shadow: 0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22)
    }

    /*----------------------------------*/
    .navbar-expand-lg.fixed-top{
            background: #fff!important;
    color: #fff;
    color: #000;
    box-shadow: 0 -18px 3px rgba(0,0,0,0.30), 0 2px 10px rgba(0,0,0,0.22);
    height: 50px;
    }
    .nav-link {
    color: #000;
}
/*------------------------------- srart edit in server -------------------------*/
  #divRegFormVideo{
   
  border-style: outset;
    float: left;
    width: 560px;
    height: 435px;
    top:160px
}
@media(max-width:768px)
{
/*    .col-lg-7-box-shadow {*/
    /*box-shadow: none!important;*/
/*}*/

.container-flud{
    padding-right: 12px;
    margin-top: 63px;
     box-shadow: 0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22); 
}

/*.row {*/
/*    margin-right:-43px;*/
    
/*}*/
.register_with_to_page header, form {
      padding-right: 14px;
    text-align: left;
    margin-right: -1px;
    margin-left: -30px;
}
.controls textarea {
     height: 200px;
     width: 100%;
 }
   #divRegFormVideo{
   
    width: 280px;
    height: 435px;
    top: 25px;
  
}
.register_with_to_page iframe{
    z-index:0 !important;
}
  
 }/* <!--end media -->*/
 
.head-h1{
   color:#555!important; 
}

/*------------------------------- End   edit in server -------------------------*/
</style>
<style>
<!--/*------------------------------- start style model    OFFER control in 2 page student tech -------------------------*/-->
.modal_countdown .content_OFFER {
    margin: 11px 0 25px 0!important;
    font-size: 29px!important;
}
.modal_countdown .text_OFFER{
    margin-top: 22px;
    margin: 14px 0;
}

.example .span {
   margin: 160px 0;!important */
    /* padding: 171px; */
    /* height: 100px; */
    margin: 12px 19px!important;
    display: block!important;
}
</style>
<!--/*------------------------------- start style model    OFFER control in 2 page student tech -------------------------*/-->






