<!-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->


<!--=========================Start Statistics =================-->
<!----------------start  section title---------------------->
<section class=" d-none  title">
    <div class="container ">
        <div class="section-header text-center">

            <h2 class="h2-section-title">
              Last  news(:
            </h2>
            <div class="line">
            </div><!--/.heazder-->
            <span class="span-border"></span>
        </div><!--/.cont div-title-->
    </div><!--/.line-->
</section><!--/.sec-title-->
<!----------------End section title------------------------->
<!-- ===================================== -->
<!--start section  statistk-->
<section class="section_content_news  d-none----- " id=" ">
    <div class="data-time">
        <aside class="container-fluid container-fluid-news">
            <!-- ================================================================= -->
            <div dir="rtl" class="news-holder">
                <div class="news">
                    <div class="new">

                        Sign Up for get all update😄 news & Get 15% off Sign Up for get😎 all update news & Get 15% offSign Up 😍for get all update

                    </div>
                    <div class="new">

                        Sign Up for get all update😄 news & Get 15% off Sign Up for get😎 all update news & Get 15% offSign Up 😍for get all update
                    </div>
                </div>
            </div>
            <!-- ================================================================= -->
        </aside>
        <div class="container">
            <div class="row">
                <div class="login">

                    <!-- ================================================================= -->
                    <!-- ================================================================= -->

                </div>
 <script type="text/javascript">
$( "#clickme" ).click(function() {
  $( "#book" ).fadeOut( "slow", function() {
    // Animation complete.
  });
});
 </script>
                
</section><!--End section  -->



<!--==============End section stitstk  ===================-->
  <style type="text/css">
.section_content_news{
    margin-bottom:-91px;
    /*margin-top:-58px;*/
}
                        .container-fluid-news {
                            padding: 0!important;
                            margin: 0!important;
                        }
                        .news-holder {
                            height: 50px;
                            padding: 0 20px;
                            color: #000!important;
                            /*background-color: #2288dd;*/
                            position: relative;
                            overflow: hidden;
                            font-size: 15px;
                            margin: -38px 0;
                            /* padding: 15px 0; */
                        }

                        .news {
                            white-space: nowrap;
                            position: absolute;
                            top: 5px;
                            right: 100%;
                            width: 100%;
                            height: 40px;
                            line-height: 40px;
                        }

                        .news .new {
                            display: inline-block;
                            padding: 0 10px;
                            color: #000;
                            position: relative;
                        }

                        .news .new:not(:last-child):after {
                            content: "";
                            width: 1px;
                            height: 24px;
                            position: absolute;
                            left: 0;
                            top: 8px;
                            background-color: #e7ded4;
                        }

                        /*=======================================================================================================*/

                        @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,700);

                        body {
                            font-family: 'Open Sans', sans-serif;
                        }

                        .login {
                            width: 100%;
                            margin: 16px auto;
                            font-size: 16px;
                        }

                        /* Reset top and bottom margins from certain elements */
                        .login-header,
                        .login p {
                            margin-top: 0;
                            margin-bottom: 0;
                        }

                        /* The triangle form is achieved by a CSS hack */
                        .login-triangle {
                            width: 0;
                            margin-right: auto;
                            margin-left: auto;
                            border: 12px solid transparent;
                            border-bottom-color: #28d;
                        }

                        .login-header {
                            background: #28d;
                            padding: 20px;
                            font-size: 1.4em;
                            font-weight: normal;
                            text-align: center;
                            text-transform: uppercase;
                            color: #fff;
                        }

                        .login-container {
                            background: #ebebeb;
                            padding: 12px;
                        }

                        /* Every row inside .login-container is defined with p tags */
                        .login p {
                            padding: 12px;
                        }

                        .login input {
                            box-sizing: border-box;
                            display: block;
                            width: 100%;
                            border-width: 1px;
                            border-style: solid;
                            padding: 16px;
                            outline: 0;
                            font-family: inherit;
                            font-size: 0.95em;
                        }

                        .login input[type="email"],
                        .login input[type="password"] {
                            background: #fff;
                            border-color: #bbb;
                            color: #555;
                        }

                        /* Text fields' focus effect */
                        .login input[type="email"]:focus,
                        .login input[type="password"]:focus {
                            border-color: #888;
                        }

                        .login input[type="submit"] {
                            background: #28d;
                            border-color: transparent;
                            color: #fff;
                            cursor: pointer;
                        }

                        .login input[type="submit"]:hover {
                            background: #17c;
                        }

                        /* Buttons' focus effect */
                        .login input[type="submit"]:focus {
                            border-color: #05a;
                        }

                        /*=======================================================================================================*/
                        /* Customization Style of SyoTimer */
                        .syotimer{
                            text-align: center;

                            margin: 30px auto 0;
                            padding: 0 0 10px;
                        }
                        .syotimer-cell{
                            display: inline-block;
                            margin: 0 5px;

                            width: 79px;
                            background: url({{ asset( 'no_image/timer.png')}}) no-repeat 0 0;
                        }
                        .syotimer-cell__value{
                            font-size: 35px;
                            color: #80a3ca;

                            height: 81px;
                            line-height: 81px;

                            margin: 0 0 5px;
                        }
                        .syotimer-cell__unit{
                            font-family: Arial, serif;
                            font-size: 12px;
                            text-transform: uppercase;
                        }

                        #simple-timer .syotimer-cell_type_day,
                        #periodic-timer_period_days .syotimer-cell_type_hour,
                        #layout-timer_only-seconds .syotimer-cell_type_second,
                        #layout-timer_mixed-units .syotimer-cell_type_minute{
                            width: 120px;
                            background-image: url({{ asset( 'no_image/timer_long.png')}});
                        }


                        .toggle-source-code{
                            width: 650px;
                            margin: 10px auto;
                            text-align: right;
                        }
                        .toggle-source-code:before{
                            font-size: .9em;
                            color: #666666;
                            border-bottom: 1px dashed #666666;
                        }
                        .toggle-source-code_action_show:before{
                            content: "Show code";
                        }
                        .toggle-source-code_action_hide:before{
                            content: "Hide code";
                        }
                    </style>

<!----------------start  section title---------------------->

<!----------------End section title------------------------->
<!--==================================== start section time news  ()================================================ -->
<!-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->

