{{-----------------------------------}}
@php
    $lang = session('lang');

    if (empty (session('lang')))
    {
    $lang ='ar';
    }
@endphp

{{-----------------------------------}}

<!--====== start Why Choose Us ?=============================== -->

<!----------------start  section title---------------------->
<section class=" title back-fff"    >
    <div class="container ">
        <div class="section-header text-center">
            <h2 class="h2-section-title" id="whyus_top" >
                {{trans('admin.taps')}} <i  class="fa fa-th"></i>
            </h2>
            <div class="line">
            </div><!--/.heazder-->
            <span class="span-border"></span>
        </div><!--/.cont div-title-->
    </div><!--/.line-->
</section><!--/.sec-title-->
<!----------------End section title------------------------->
<!-- Button to Open the Modal -->
<!-- The Modal -->

<!-- ===================================== -->
<!--start section  statistk-->

<section class="tabs_move">
    <div class="  " >
        <div class="container-fluid custom_new">
            <div class="row">
            <div class="col-md-6">
                <!-- ----------------------------------------------------------------------------- -->
  <section class="content_tabe">
<div class="container theme-cactus">
   <div class="ui-tabgroup">
    <input class="ui-tab1" type="radio" id="tgroup_c1_tab1" name="tgroup_c1" checked />
    <input class="ui-tab2" type="radio" id="tgroup_c1_tab2" name="tgroup_c1" />
    <input class="ui-tab3" type="radio" id="tgroup_c1_tab3" name="tgroup_c1" />
    <input class="ui-tab4" type="radio" id="tgroup_c1_tab4" name="tgroup_c1" />
    <div class="ui-tabs">
      <label class="ui-tab1" for="tgroup_c1_tab1"><i class="fa fa-certificate"></i>Cactus Lorem</label>
      <label class="ui-tab2" for="tgroup_c1_tab2"><i class="fa fa-list"></i>Ipsum</label>
      <label class="ui-tab3" for="tgroup_c1_tab3"><i class="fa fa-rocket"></i>Dolor Sit Amet</label>
      <label class="ui-tab4" for="tgroup_c1_tab4"><i class="fa fa-cloud-upload"></i>Consectetur</label>
    </div>
    <div class="ui-panels">
      <div class="ui-tab1">
        <h3>Lorem ipsum</h3>
          <p>
              Lorem ipsum
              Lorem ipsum Quran Ayat is an online institute that provides Arabic and Quran lessons for you and your children through highly qualified and experienced teachers from Egypt who have studied Arabic and Quran in Al-Azhar University. They have many years of experience in Arabic and Quran teaching for non-Arabic speakers. In Quran Ayat, we provide the most proper educational materials to help you practice what you learn around the clock, not only during the lessons. We focus on providing interactive lessons for you and all of your family. We follow your performance in the homework assigned to you and your children at each lesson. Then, we provide tests for you to ensure that you improve and make progress in your lessons. You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids and adults. We cater to all age groups as we strongly believe the knowledge of the Quran to be highly significant and valuable to people of all ages. You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam,          </p>
          </div>
      <div class="ui-tab2">
        <h3>Duis aute</h3>
        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
          {{-------------------------------}}
          <article>
              <div class="ui-tabgroup left-side">
                  <input class="ui-tab1" type="radio" id="tgroup_c2_tab1" name="tgroup_c2" checked />
                  <input class="ui-tab2" type="radio" id="tgroup_c2_tab2" name="tgroup_c2" />
                  <input class="ui-tab3" type="radio" id="tgroup_c2_tab3" name="tgroup_c2" />
                  <input class="ui-tab4" type="radio" id="tgroup_c2_tab4" name="tgroup_c2" />
                  <div class="ui-tabs">
                      <label class="ui-tab1" for="tgroup_c2_tab1"><i class="fa fa-list"></i>Aliqua</label>
                      <label class="ui-tab2" for="tgroup_c2_tab2"><i class="fa fa-rocket"></i>Proident</label>
                      <label class="ui-tab3" for="tgroup_c2_tab3"><i class="fa fa-cog"></i>Velit Esse</label>
                      <label class="ui-tab4" for="tgroup_c2_tab4"><i class="fa fa-cloud-upload"></i>Minim</label>
                  </div>
                  <div class="ui-panels">
                      <div class="ui-tab1">
                          <h3>Lorem ipsum</h3>
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                      </div>
                      <div class="ui-tab2">
                          <h3>Duis aute</h3>
                          <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                      </div>
                      <div class="ui-tab3">
                          <h3>Not much here</h3>
                          <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                      </div>
                      <div class="ui-tab4">
                          <h3>Ut enim ad minim veniam</h3>
                          <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                      </div>
                  </div>
              </div>
          </article>
          {{-------------------------------}}      </div>
      <div class="ui-tab3">
        <h3>Not much here</h3>
             <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>

      </div>
      <div class="ui-tab4">
        <h3>Ut enim ad minim veniam</h3>
        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, <a href="#">a link</a>. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
      </div>
    </div>
  </div>


</div>

</section>




<!-- ----------------------------------------------------------------------------- -->
            </div><!--Col-md-6-->
            <div class="col-md-6 col_content_accordion">
{{--     ------------------------------------------------------------}}
    <h2>WHAT YOU WILL LEARN</h2>
                 <!-- Contenedor -->
                <ul id="accordion" class="accordion">
                    <li>
                        <div class="link"><i class="fa fa-globe"></i>Global<i class="fa fa-chevron-down"></i></div>
                        <ul class="submenu">
                            <li>
                                <article>Lorem ipsum
                                    Quran Ayat is an online institute that provides Arabic and Quran lessons for you and your children through highly qualified and experienced teachers from Egypt who have studied Arabic and Quran in Al-Azhar University. They have many years of experience in Arabic and Quran teaching for non-Arabic speakers. In Quran Ayat, we provide the most proper educational materials to help you practice what you learn around the clock, not only during the lessons. We focus on providing interactive lessons for you and all of your family. We follow your performance in the homework assigned to you and your children at each lesson. Then, we provide tests for you to ensure that you improve and make progress in your lessons. You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids and adults. We cater to all age groups as we strongly believe the knowledge of the Quran to be highly significant and valuable to people of all ages.</article>
                            </li>
                        </ul>
                    </li>{{-- ----End li--}}
                    <li>
                        <div class="link"><i class="fa fa-globe"></i>Global<i class="fa fa-chevron-down"></i></div>
                        <ul class="submenu">
                            <li>
                                <article>Lorem ipsum
                                    Quran Ayat is an online institute that provides Arabic and Quran lessons for you and your children through highly qualified and experienced teachers from Egypt who have studied Arabic and Quran in Al-Azhar University. They have many years of experience in Arabic and Quran teaching for non-Arabic speakers. In Quran Ayat, we provide the most proper educational materials to help you practice what you learn around the clock, not only during the lessons. We focus on providing interactive lessons for you and all of your family. We follow your performance in the homework assigned to you and your children at each lesson. Then, we provide tests for you to ensure that you improve and make progress in your lessons. You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids and adults. We cater to all age groups as we strongly believe the knowledge of the Quran to be highly significant and valuable to people of all ages.</article>
                            </li>
                        </ul>
                    </li>{{-- ----End li--}}
                    <li>
                        <div class="link"><i class="fa fa-globe"></i>Global<i class="fa fa-chevron-down"></i></div>
                        <ul class="submenu">
                            <li>
                                <article>Lorem ipsum
                                    Quran Ayat is an online institute that provides Arabic and Quran lessons for you and your children through highly qualified and experienced teachers from Egypt who have studied Arabic and Quran in Al-Azhar University. They have many years of experience in Arabic and Quran teaching for non-Arabic speakers. In Quran Ayat, we provide the most proper educational materials to help you practice what you learn around the clock, not only during the lessons. We focus on providing interactive lessons for you and all of your family. We follow your performance in the homework assigned to you and your children at each lesson. Then, we provide tests for you to ensure that you improve and make progress in your lessons. You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids and adults. We cater to all age groups as we strongly believe the knowledge of the Quran to be highly significant and valuable to people of all ages.</article>
                            </li>
                        </ul>
                    </li>{{-- ----End li--}}
                    <li>
                        <div class="link"><i class="fa fa-globe"></i>Global<i class="fa fa-chevron-down"></i></div>
                        <ul class="submenu">
                            <li>
                                <article>Lorem ipsum
                                    Quran Ayat is an online institute that provides Arabic and Quran lessons for you and your children through highly qualified and experienced teachers from Egypt who have studied Arabic and Quran in Al-Azhar University. They have many years of experience in Arabic and Quran teaching for non-Arabic speakers. In Quran Ayat, we provide the most proper educational materials to help you practice what you learn around the clock, not only during the lessons. We focus on providing interactive lessons for you and all of your family. We follow your performance in the homework assigned to you and your children at each lesson. Then, we provide tests for you to ensure that you improve and make progress in your lessons. You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids and adults. We cater to all age groups as we strongly believe the knowledge of the Quran to be highly significant and valuable to people of all ages.</article>
                            </li>
                        </ul>
                    </li>{{-- ----End li--}}
                    <li>
                        <div class="link"><i class="fa fa-globe"></i>Global<i class="fa fa-chevron-down"></i></div>
                        <ul class="submenu">
                            <li>
                                <article>Lorem ipsum
                                    Quran Ayat is an online institute that provides Arabic and Quran lessons for you and your children through highly qualified and experienced teachers from Egypt who have studied Arabic and Quran in Al-Azhar University. They have many years of experience in Arabic and Quran teaching for non-Arabic speakers. In Quran Ayat, we provide the most proper educational materials to help you practice what you learn around the clock, not only during the lessons. We focus on providing interactive lessons for you and all of your family. We follow your performance in the homework assigned to you and your children at each lesson. Then, we provide tests for you to ensure that you improve and make progress in your lessons. You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids and adults. We cater to all age groups as we strongly believe the knowledge of the Quran to be highly significant and valuable to people of all ages.</article>
                            </li>
                        </ul>
                    </li>{{-- ----End li--}}
                    <li>
                        <div class="link"><i class="fa fa-globe"></i>Global<i class="fa fa-chevron-down"></i></div>
                        <ul class="submenu">
                            <li>
                                <article>Lorem ipsum
                                    Quran Ayat is an online institute that provides Arabic and Quran lessons for you and your children through highly qualified and experienced teachers from Egypt who have studied Arabic and Quran in Al-Azhar University. They have many years of experience in Arabic and Quran teaching for non-Arabic speakers. In Quran Ayat, we provide the most proper educational materials to help you practice what you learn around the clock, not only during the lessons. We focus on providing interactive lessons for you and all of your family. We follow your performance in the homework assigned to you and your children at each lesson. Then, we provide tests for you to ensure that you improve and make progress in your lessons. You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids and adults. We cater to all age groups as we strongly believe the knowledge of the Quran to be highly significant and valuable to people of all ages.</article>
                            </li>
                        </ul>
                    </li>{{-- ----End li--}}
                    <li>
                        <div class="link"><i class="fa fa-globe"></i>Global<i class="fa fa-chevron-down"></i></div>
                        <ul class="submenu">
                            <li>
                                <article>Lorem ipsum
                                    Quran Ayat is an online institute that provides Arabic and Quran lessons for you and your children through highly qualified and experienced teachers from Egypt who have studied Arabic and Quran in Al-Azhar University. They have many years of experience in Arabic and Quran teaching for non-Arabic speakers. In Quran Ayat, we provide the most proper educational materials to help you practice what you learn around the clock, not only during the lessons. We focus on providing interactive lessons for you and all of your family. We follow your performance in the homework assigned to you and your children at each lesson. Then, we provide tests for you to ensure that you improve and make progress in your lessons. You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids and adults. We cater to all age groups as we strongly believe the knowledge of the Quran to be highly significant and valuable to people of all ages.</article>
                            </li>
                        </ul>
                    </li>{{-- ----End li--}}
                    <li>
                        <div class="link"><i class="fa fa-globe"></i>Global<i class="fa fa-chevron-down"></i></div>
                        <ul class="submenu">
                            <li>
                                <article>Lorem ipsum
                                    Quran Ayat is an online institute that provides Arabic and Quran lessons for you and your children through highly qualified and experienced teachers from Egypt who have studied Arabic and Quran in Al-Azhar University. They have many years of experience in Arabic and Quran teaching for non-Arabic speakers. In Quran Ayat, we provide the most proper educational materials to help you practice what you learn around the clock, not only during the lessons. We focus on providing interactive lessons for you and all of your family. We follow your performance in the homework assigned to you and your children at each lesson. Then, we provide tests for you to ensure that you improve and make progress in your lessons. You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids and adults. We cater to all age groups as we strongly believe the knowledge of the Quran to be highly significant and valuable to people of all ages.</article>
                            </li>
                        </ul>
                    </li>{{-- ----End li--}}
                    <li>
                        <div class="link"><i class="fa fa-globe"></i>Global<i class="fa fa-chevron-down"></i></div>
                        <ul class="submenu">
                            <li>
                                <article>Lorem ipsum
                                    Quran Ayat is an online institute that provides Arabic and Quran lessons for you and your children through highly qualified and experienced teachers from Egypt who have studied Arabic and Quran in Al-Azhar University. They have many years of experience in Arabic and Quran teaching for non-Arabic speakers. In Quran Ayat, we provide the most proper educational materials to help you practice what you learn around the clock, not only during the lessons. We focus on providing interactive lessons for you and all of your family. We follow your performance in the homework assigned to you and your children at each lesson. Then, we provide tests for you to ensure that you improve and make progress in your lessons. You are never too young neither too old to learn. Quran Ayat Institute provides Quran, Islam, and Arabic lessons for both kids and adults. We cater to all age groups as we strongly believe the knowledge of the Quran to be highly significant and valuable to people of all ages.</article>
                            </li>
                        </ul>
                    </li>{{-- ----End li--}}

                </ul>
{{--     ------------------------------------------------------------}}

            </div><!-- col-md-6" -->

            </div><!-- row" -->
        </div><!--  container -->
    </div><!--  data-n -->

</section><!--End section  -->
<!--End section stitstk -->
<!--====================================== End  Why Choose Us ?=============================== -->
