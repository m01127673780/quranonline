 
 
@include('style.layouts.header')
@include('style.layouts.style_page_login')


@include('style.layouts.navbar')
 
 
@include('style.student_form')

 

 



 @include('style.layouts.footer')
 @include('style.layouts.script_page_login')
 