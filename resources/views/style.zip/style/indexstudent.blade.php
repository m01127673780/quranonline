@include('style.layouts.header')
@include('style.layouts.sidbar')



@include('style.layouts.section_header')
@include('style.layouts.quick_register')
 @include('style.layouts.whychoose_us')


@include('style.layouts.section_courses')
@include('style.layouts.section_videos')
@include('style.layouts.tabs_move')
{{--@include('style.layouts.read_greatest')--}}
@include('style.layouts.read_greatest_content')
@include('style.layouts.q_s_videos')
@include('style.layouts.Jobs')

















<section class="bg-f3f3f3"  >

@include('style.layouts.section_teachers')
@include('style.layouts.section_price')
@include('style.layouts.section_testimonials')
@include('style.layouts.section_statistics')

@include('style.layouts.section_perfect_student')








   {{-- @include('style.layouts.section_news_time')--}}


























@include('style.layouts.section_footer')
@include('style.layouts.footer')